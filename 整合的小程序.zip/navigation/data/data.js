const dataList = [
    "http://imoeu.com.img.800cdn.com/html/wechat/images/yunshi/mv-01.jpeg",
    "http://imoeu.com.img.800cdn.com/html/wechat/images/yunshi/mv-02.jpeg",
    "http://imoeu.com.img.800cdn.com/html/wechat/images/yunshi/mv-03.jpeg",
    "http://imoeu.com.img.800cdn.com/html/wechat/images/yunshi/mv-04.jpeg"
  ]

module.exports = {
  dataList: dataList
}