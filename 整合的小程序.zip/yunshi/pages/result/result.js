// pages/result/result.js
const app = getApp;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ldata:false,
    pixelRatio: 0,
    windowWidth: 0,
    windowHeight: 0,
    showBgImagePath: '',
    showBgImagePath2: '../../images/showtextBg.png',
    showBgImagePath3: '../../images/showtextBg.png',
    dogBgImagePath: '',
    dogBgImagePath2: '../../images/dog@2x.png',
    dogBgImagePath3: '../../images/dog@3x.png',
    // qrBgImagePath: '',
    // qrBgImagePath2: '',
    name: '',
    title: '',
    desc: ''
  },
  /**
   * 换个名字测
   */
  returnIndex: function() {
    wx.redirectTo({
      url: '../yunshi/yunshi'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let that = this;
    let arr = wx.getStorageSync('currentFortuneData') || {};
    this.setData({
      name: arr.name + '的七夕运势',
      title: arr.title,
      desc: arr.desc
    })

    wx: wx.getSystemInfo({
      success: function(res) {
        that.setData({
          pixelRatio: res.pixelRatio,
          windowWidth: res.windowWidth,
          windowHeight: res.windowHeight
        })
      }
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    this.drawCanvas();
  },
  /**
     * 生命周期函数--监听页面显示
     */
  onShow: function () {
    // this.drawCanvas();
  },
  /**
   * canvas绘制图片
   */
  drawCanvas: function() {
    // 根据像素比绘画不同的图片
    let that = this;
    if (that.data.pixelRatio == 2) {
      that.setData({
        showBgImagePath: that.data.showBgImagePath2,
        dogBgImagePath: that.data.dogBgImagePath2,
        // qrBgImagePath: that.data.qrBgImagePath2
      })
    } else {
      that.setData({
        showBgImagePath: that.data.showBgImagePath3,
        dogBgImagePath: that.data.dogBgImagePath3,
        // qrBgImagePath: that.data.qrBgImagePath2
      })
    }
    // console.log(that.data.qrBgImagePath,"00")
    let imgs = wx.getStorageSync('imgs');
    let ctx = wx.createCanvasContext('myCanvas');
    // 画布宽高
    let ctxW = that.data.windowWidth;
    let ctxH = 500;
    let pixelRatio = that.data.pixelRatio; //默认像素比
    let XS = that.data.windowWidth / 375;

    const grd = ctx.createLinearGradient(0, 0, 0, ctxH);
    grd.addColorStop(0, '#FFC0CB');
    grd.addColorStop(1, '#FFB6C1');
    ctx.setFillStyle(grd);

    ctx.fillRect(0, 0, ctxW, ctxH);

    ctx.drawImage(that.data.showBgImagePath, ctxW / 2 - 158 * XS, 34 * XS, 317 * XS, 368 * XS);
    ctx.drawImage(that.data.dogBgImagePath, 20 * XS, 331 * XS, 61 * XS, 98 * XS);
    ctx.drawImage(wx.getStorageSync('imgs'), 400 * XS, 91 * XS, 98 * XS);

    ctx.setFontSize(18 * XS);
    ctx.setFillStyle('#F7F7FA');
    ctx.setTextAlign('center');
    ctx.setTextBaseline('middle');
    ctx.fillText(that.data.name, ctxW / 2, 58 * XS);

    ctx.setTextAlign('center');
    ctx.setTextBaseline('middle');
    ctx.setFontSize(35 * XS);
    ctx.setFillStyle('#232884');
    that.fontLineFeed(ctx, that.data.title, 1, 38 * XS, ctxW / 2, 120 * XS);

    ctx.setTextAlign('center');
    ctx.setTextBaseline('middle');
    ctx.setFontSize(14);
    ctx.setFillStyle('#ff0000');
    that.fontLineFeed(ctx, that.data.desc, 18 * XS, 20 * XS, 200 * XS, 330 * XS);

    ctx.drawImage(imgs, ctxW / 2 - 46 * XS, 400 * XS, 80 * XS, 80 * XS);

    ctx.stroke();
    ctx.draw();
  },

  /**
   * ctx,画布对象
   * str,需要绘制的文字
   * splitLen,切割的长度字符串
   * strHeight,每行文字之间的高度
   * x,位置
   */
  fontLineFeed: function(ctx, str, splitLen, strHeight, x, y) {
    let strArr = [];
    for (let i = 0, len = str.length / splitLen; i < len; i++) {
      strArr.push(str.substring(i * splitLen, i * splitLen + splitLen));
    }
    let s = 0;
    for (let j = 0, len = strArr.length; j < len; j++) {
      s = s + strHeight;
      ctx.fillText(strArr[j], x, y + s);
    }
  },
  /**
   * 保存图片
   */
  saveImage: function(e) {
    let that = this;
    wx.canvasToTempFilePath({
      canvasId: 'myCanvas',
      success: function(res) {
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
          success:function(res){
            wx.showToast({
              title: '图片保存成功',
              icon:'success',
              duration:2000
            })
          },fail:function(e){
            that.setData({
              ldata: !that.data.ldata
            })
          }
        })
      }
    })
  },
  handler: function (e) {
    var that = this;
    if (!e.detail.authSetting['scope.writePhotosAlbum']) {
      that.setData({
        ldata: that.data.ldata
      })
    } else {
      that.setData({
        ldata: !that.data.ldata,
      })
    }
  },
  
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function(res) {
    return {
      title: '测一测，好运来',
      path: 'pages/yunshi/yunshi',
      imageUrl:'../../images/dot.png',
      success: function (res) {
        // 转发成功
        wx.showToast({
          title: '转发成功',
          icon: 'success',
          duration: 2000
        })
      },
      fail: function (res) {
        // 转发失败
        wx.showToast({
          title: '转发失败',
          icon: 'loading',
          duration: 2000
        })
      }
    }
  }
})