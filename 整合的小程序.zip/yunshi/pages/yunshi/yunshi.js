// pages/yunshi/yunshi.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isPlayMusic: true,
    userName: '请输入你的名字',
    color: '#fff',
    kfhidden: '分享好友',
    userInputName: '',
    pixelRatio: '', //设备像素,
    indexHeadInputBgSrc: '',
    indexHeadInputBgSrc2: '../../images/inputBg.png',
    indexHeadInputBgSrc3: '../../images/inputBg.png',
    fortuneArr: [{
        title: '加班狗',
        desc: '别人都是成双成对，只有你不仅要做单身狗，还的是加班狗'
      },
      {
        title: '心想意成',
        desc: '你喜欢的人同样也在喜欢你，赶紧乘机表白吧！'
      },
      {
        title: '颜值爆表',
        desc: '颜值即正义，颜值爆表的你，就是地球一道绚丽的风景线！'
      },
      {
        title: '吃不胖',
        desc: '不管是一日三餐，还是甜食夜宵，吃前吃后一个样，反正别人都胖我不胖。'
      },
      {
        title: '一夜暴富',
        desc: '你有福了，终于迎来转运，很有可能一夜暴富，横财爆发，不缺富贵不缺钱。'
      },
      {
        title: '苦尽甘来',
        desc: '辛苦这么久了，也该轮到我了吧~'
      },
      {
        title: '桃花不停',
        desc: '不要宅在家里，出去走走，说不定就可以碰到命中注定的人'
      },
      {
        title: '瘦瘦瘦',
        desc: '明天过后，你将瘦成一道闪电。'
      },
      {
        title: '年轻十岁',
        desc: '面带桃花，姻缘自然来'
      },
      {
        title: '梦想成真',
        desc: '大胆想，勇敢做，万一梦想变成真，下个比尔盖斯就是你。'
      },
      {
        title: '事事顺心',
        desc: '今年家庭、事业、爱情将一帆风顺，事事顺心事事成。'
      },
      {
        title: '智商爆表',
        desc: '一眼就能识破真相，洞察和逻辑能力杠杠的，下个最强大脑就是你。'
      },
      {
        title: '赚一个亿',
        desc: '恭喜你，你的目标马上就能实现了，说不定你就是中国下一个比尔盖茨。'
      },
      {
        title: '沉鱼落雁',
        desc: '整个人都美美哒，仙女下凡了'
      },
      {
        title: '单身狗',
        desc: '你愁啥，说的就是你~'
      },
      {
        title: '肥宅',
        desc: '快点出去走走吧，不然该不会走路了'
      },
      {
        title: '逢凶化吉',
        desc: '俗说人生不如意之事十有八九，善良的你往往能逢凶化吉。'
      },
      {
        title: '捡到钱',
        desc: '从早上一直捡到晚上，根本停不下来'
      },
      {
        title: '小确幸',
        desc: '每天生活都是满满的幸福！'
      },
      {
        title: '运气爆棚',
        desc: '抓住机遇，人生就像开了挂，飞鸿腾达，一飞冲天。'
      },
      {
        title: '人品爆棚',
        desc: '走在路上也能捡到钱，是时候要去买买彩票中大奖了。'
      },
      {
        title: '婚姻美满',
        desc: '和爱人拍拖多年，终于走上了婚姻的殿堂，从此过上幸福美满的生活。'
      },
      {
        title: '疯狂加班',
        desc: '加班！加班！加班！加班！加班！加班！加班！，重要的事情说六遍'
      },
      {
        title: '666',
        desc: '今天的你做什么都是事半功倍'
      },
      {
        title: '有钱任性',
        desc: '没错！有钱就可以任性，说的就是你'
      },
      {
        title: '靠脸吃饭',
        desc: '你的美貌倾国倾城，你完全可以靠脸吃饭，没必要靠才华赚钱。'
      },
      {
        title: '靠才华',
        desc: '明明可以靠脸吃饭，但你偏偏靠才华！你用实力证明了你寄几，可喜可贺！'
      },
      {
        title: '皮皮虾走',
        desc: '皮皮虾将带你走向人生巅峰，新的一天你将事事顺心。'
      },
      {
        title: '大吉大利',
        desc: '大吉大利，今晚吃鸡！相信你能够成为最后的逃生者，赢取最终的胜利！'
      },
      {
        title: '百毒不侵',
        desc: '七夕当天你将无所畏惧，无论遇到什么事情都无法伤害你！'
      },
      {
        title: '处变不惊',
        desc: '你将拥有临危不惧的处事能力，这个能力非常重要，相信会对你未来带来大的变化！'
      },
      {
        title: '撸起袖子',
        desc: '撸起袖子加油干！幸福都是靠自己来争取，相信你会越来越好'
      },
      {
        title: '摇到车牌',
        desc: '一线城市的车牌有多难相信你都知道了！恭喜你，有福星高照，很快就荣获一枚车牌。'
      },
      {
        title: '吃货一枚',
        desc: '空有一颗想减肥的心，偏偏生了一条吃货的命。横扫天下美食，享受人间美味。'
      },
      {
        title: '鞭策自己',
        desc: '既然选择了远方，便只顾风雨兼程，只为遇到更好的自己。'
      },
      {
        title: '戏精',
        desc: '语言肢体动作十分丰富，总能为身边的人带来欢乐，下个小金人就是你。'
      },
      {
        title: '不差钱',
        desc: '别人最多的是时间，而我最多的是金钱，怎么花都花不完。'
      },
      {
        title: '都是浮云',
        desc: '繁华落尽，曾经在意、不舍的东西，已不值一提。神马都是浮云！'
      }
    ]
  },
  /**
   * 获取用户输入的名字
   */
  bindNameInput: function(e) {
    this.setData({
      userInputName: e.detail.value
    })
    let value = e.detail.value;
    console.log(value);
    if (!value.replace(/[^\u4E00-\u9FA5]/g, '')) {
      this.setData({
        userName: '请输入中文',
        color: '#ff0000'
      })
    } else {
      this.setData({
        userName: '请输入你的名字',
        color: '#fff'
      })
    }
  },
  bindCancelName: function(e) {
    this.setData({
      userName: '请输入你的名字',
      color: '#fff'
    })
  },
  /**
   * 分析事件按钮
   */
  getUserFortune: function(e) {
    let that = this;
    if (that.data.userInputName) {
      let currentFortuneData = that.getUserIsFortune(that.data.userInputName);
      // 名字已经测试过运势
      if (currentFortuneData && currentFortuneData.name) {
        wx.setStorageSync('currentFortuneData', currentFortuneData);
      } else {
        let max = that.data.fortuneArr.length;
        let min = 0;
        let ranNumber = parseInt(Math.random() * (max - min) + min, 10);
        let obj = {
          'title': that.data.fortuneArr[ranNumber].title,
          'desc': that.data.fortuneArr[ranNumber].desc,
          'name': that.data.userInputName
        };
        that.addUserFortune(obj);
        wx.setStorageSync('currentFortuneData', obj)
      }
      // 关闭本页面并跳转
      if (that.data.color === '#ff0000') {
        wx.showModal({
          title: '温馨提示',
          content: '请使用中文输入，不然无法显示检测结果哦~',
          showCancel: false
        })
      } else {
        wx.redirectTo({
          url: '../result/result',
        })
      }

    } else {
      wx.showToast({
        title: '请输入您的名字',
        icon: 'loading',
        duration: 1000
      })
    }
  },
  /**
   * 判断该名字是否测试过运势
   */
  getUserIsFortune: function(name) {
    let returnVal = {};
    let arr = wx.getStorageSync('fortuneData') || [];
    for (let i = 0, len = arr.length; i < len; i++) {
      if (arr[i].name == name) {
        returnVal = arr[i];
        break;
      }
    }
    return returnVal;
  },
  /**
   * 添加数据缓存
   */
  addUserFortune: function(obj) {
    let arr = wx.getStorageSync('fortuneData') || [];
    arr.push(obj);
    wx.getStorageSync('fortuneData', arr);

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let that = this;
    let pixelRatio = that.getPixelRatio();
    if (pixelRatio == 2) {
      that.setData({
        indexHeadInputBgSrc: that.data.indexHeadInputBgSrc2
      });
    } else {
      that.setData({
        indexHeadInputBgSrc: that.data.indexHeadInputBgSrc3
      })
    }
    that.setData({
      pixelRatio: pixelRatio
    })
    setTimeout(function(){
      wx.showToast({
        title: '音乐响起来',
        icon:'none',
        duration:1000
      })
      wx.playBackgroundAudio({
        dataUrl: 'http://pei84s.cn/html/wechat/images/yunshi/keneng.mp3',
        title: '一百万个可能',
        coverImgUrl: ''
      });
    },1500)
    that.setMusicMonitor();
    that.controlTap();
  },
  /**
   * 暂停音乐
   */
  onPauseMusic: function(e) {
    let that = this;
    that.setData({
      isPlayMusic: !that.data.isPlayMusic
    })
    wx.pauseBackgroundAudio()
  },
  /**
   * 开始音乐
   */
  onStartMusic: function(e) {
    let that = this;
    that.setData({
      isPlayMusic: !that.data.isPlayMusic
    })
    wx.playBackgroundAudio({
      dataUrl: 'http://pei84s.cn/html/wechat/images/yunshi/keneng.mp3',
      title: '好运来',
      coverImgUrl: ''
    })
  },
  
  /**
   * 监听音乐播放停止
   */
  setMusicMonitor: function () {
    let that = this;
    wx.onBackgroundAudioStop(function () {
      that.setData({
        isPlayMusic: false
      })
    })
  },
  /**
 * 控制开关
 */
  controlTap: function () {
    let that = this;
    wx.request({
      url: 'https://pei84s.cn/api/XcxKeysGet.html',
      data: {
        openid: wx.getStorageSync('openid'),
        appid: 'wx1156b60f7bba1f91'
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.log(res.data, "999")
        if (res.data != '') {

          var arrs = res.data;
          if (arrs['key6'] === that.data.kfhidden) {
            console.log(arrs['key6'], "9992")
            that.setData({
              kfhidden: true
            })
          } else {
            that.setData({
              kfhidden: false
            });
            wx.showModal({
              title: '温馨提示',
              content: '页面崩溃了呢，请联系客服人员反馈问题',
              showCancel: false
            })
          }
        }
      }
    })
  },
  /**
   * 后台音乐停止
   */
  setMusicStop: function () {
    let that = this;
    wx.stopBackgroundAudio(function () {
      that.setData({
        isPlayMusic: false
      })
    })
  },
  /**
   * 获取设备像素比
   */
  getPixelRatio: function() {
    let pixelRatio = 0;
    wx.getSystemInfo({
      success: function(res) {
        pixelRatio = res.pixelRatio
        console.log(res.pixelRatio)
      },
      fail: function() {
        pixelRatio = 0
      }
    })
    return pixelRatio
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.setMusicStop();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})